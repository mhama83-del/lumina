<?php

namespace App\Controllers;

use App\Services\ScoreService;

class Home extends BaseController
{
    public function index()
    {
        return view('home/landing', ['title' => 'Lumina — AI Talent Intelligence Layer']);
    }

    public function architecture()
    {
        return view('home/architecture', ['title' => 'Lumina · How it works']);
    }

    public function graph()
    {
        $db  = \Config\Database::connect();
        $tax = new \App\Services\TaxonomyService();
        $stats        = $tax->stats();
        $topSkills    = $db->table('taxonomy_skills')->orderBy('frequency', 'DESC')->limit(16)->get()->getResultArray();
        $rolePatterns = $db->table('taxonomy_patterns')->where('programme LIKE', 'JD:%')->orderBy('domain', 'ASC')->orderBy('programme', 'ASC')->get()->getResultArray();
        $newest       = $db->table('taxonomy_skills')->orderBy('id', 'DESC')->limit(8)->get()->getResultArray();
        foreach ($newest as &$ns) {
            $ns['related']  = json_decode($ns['related_skills_json'] ?? '[]', true) ?: [];
            $ns['patterns'] = array_column(
                $db->table('taxonomy_patterns')->select('pattern_key')
                   ->like('typical_skills_json', '"' . $ns['code'] . '"')->limit(4)->get()->getResultArray(),
                'pattern_key'
            );
            // employer connection: roles needing this skill OR one of its related skills
            $codes = array_values(array_unique(array_merge([$ns['code']], $ns['related'])));
            $fams = array_column($db->table('employer_skill_requirements s')->join('employer_roles r', 'r.id = s.role_id')
                ->select('r.role_family')->distinct()->whereIn('s.skill_code', $codes)->limit(300)->get()->getResultArray(), 'role_family');
            $fams = array_values(array_unique(array_filter($fams)));
            $ns['role_count'] = count($fams);
            $ns['role_examples'] = array_slice($fams, 0, 3);
        }
        unset($ns);
        // skills added/updated to the graph in the last 24h — used to highlight "new" skills wherever they appear (e.g. inside role-market pattern skill lists)
        $freshCodes = array_column(
            $db->table('taxonomy_skills')->select('code')
               ->where('created_at >=', date('Y-m-d H:i:s', strtotime('-1 day')))
               ->get()->getResultArray(),
            'code'
        );
        return view('home/graph', [
            'title' => 'Lumina Graph', 'stats' => $stats,
            'topSkills' => $topSkills, 'rolePatterns' => $rolePatterns,
            'newest' => $newest, 'freshCodes' => $freshCodes,
        ]);
    }

    public function styleguide()
    {
        return view('home/styleguide', ['title' => 'Lumina · Style Guide']);
    }

    /**
     * Fasa 1 DoD: run the Aiman persona through ScoreService end-to-end.
     */
    public function selftest()
    {
        $svc = new ScoreService();
        $evidence = 'Treasurer of the Robotics Club for 2 years; built an attendance app; led a data project.';
        $skills   = $svc->inferSkills($evidence, ['python', 'teamwork']);
        $cand = [
            'skills'     => $skills,
            'top_domain' => 'Data',
            'verified'   => 1, 'projects' => 2, 'activities' => 3, 'pace' => 'Steady',
        ];
        $role = ['domain' => 'Data', 'required' => ['sql', 'dashboarding', 'python', 'data_analysis']];
        $readiness = $svc->readiness($cand, $role);
        $match     = $svc->match($cand, $role);
        $whatif    = $svc->whatIf($cand, $role, ['sql', 'dashboarding']);

        $report  = "INFERRED SKILLS:\n";
        foreach ($skills as $code => $s) {
            $report .= sprintf("  - %-18s %s (%.0f%%)\n", $code, $s['source'], $s['confidence'] * 100);
        }
        $report .= "\nREADINESS (Data Analyst): {$readiness['score']}%";
        $report .= "  [coverage {$readiness['coverage']}, evidence {$readiness['evidence']}, activity {$readiness['activity']}, pace {$readiness['pace']}]\n";
        $report .= "\nMATCH: {$match['matchScore']}% ({$match['label']})";
        $report .= "  gap: " . implode(', ', $match['gap']) . "\n";
        $report .= "\nWHAT-IF (add SQL + dashboarding): {$whatif['before']}% -> {$whatif['after']}%  (+{$whatif['delta']})\n";
        $report .= "\nExpected: what-if delta is positive and readiness rises. OK if numbers look right.";

        return view('home/selftest', ['title' => 'Lumina · Self-test', 'report' => $report]);
    }
}
