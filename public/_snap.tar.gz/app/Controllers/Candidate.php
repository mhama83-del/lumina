<?php

namespace App\Controllers;

use App\Libraries\WorkAnimal;
use App\Libraries\Edge;
use App\Libraries\Explain;
use App\Services\ScoreService;

class Candidate extends BaseController
{
    private const SAMPLE_MYCSD =
        'Treasurer of the Computer Science Society for 2 years, managing an RM6,000 annual budget; '
      . 'volunteered in a community coding programme teaching Python to 30 secondary students; '
      . 'built a faculty attendance web app that cut manual roll-call time by 80%; '
      . 'led a student data analysis project, building dashboards used by 5 lecturers.';

    /** The 11 Lumina domains (ISCED-F 2013 grounded). */
    private const VALID_DOMAINS = [
        'Data', 'Engineering', 'Design', 'Business',
        'Education', 'Arts & Humanities', 'Social Sciences', 'Natural Sciences',
        'Agriculture & Veterinary', 'Health & Welfare', 'Services',
    ];

    // ---------- Fasa 2 landing ----------
    public function home()
    {
        if (session('role') !== 'candidate') {
            session()->set(['role' => 'candidate', 'stage' => session('stage') ?? '19-22']);
        }
        return view('candidate/home', ['title' => 'Lumina · Candidate', 'profile' => session('profile') ?? null]);
    }

    // ---------- Fasa 3: entry chooser ----------
    public function start()
    {
        return view('candidate/start', ['title' => 'Lumina · Start']);
    }

    /** Use a ready sample persona, skip straight to a populated Passport. */
    public function sample()
    {
        $stage = session('stage') ?? '19-22';
        $p = $this->samplePreset($stage);
        // Strategic C fix: sample personas skip the assessment entirely, so
        // pre-fill their EDGE Signal quiz tally into session before
        // buildProfile() reads it — avoids a flat 50-baseline radar chart.
        $profile = session('profile') ?? [];
        $profile['quiz_ps'] = $p['quiz_ps'] ?? [];
        session()->set('profile', $profile);
        $this->buildProfile($p['evidence_text'], $p['stated'], $p['domain'], $p['animal'], $p['verified'], $p['name'], [
            'programme'  => $p['programme']  ?? null,
            'university' => $p['university'] ?? null,
            'cgpa'       => $p['cgpa']       ?? null,
            'study_year' => $p['study_year'] ?? null,
        ]);
        return redirect()->to(base_url('passport'));
    }

    // ---------- Fasa 3: Work Animal ----------
    public function animal()
    {
        if ($this->request->getMethod() === 'POST') {
            $answers = $this->request->getPost('a') ?? [];
            $id = WorkAnimal::score(array_values($answers));
            $a = WorkAnimal::get($id);
            $profile = session('profile') ?? [];
            $profile['animal']      = $id;
            $profile['animalLabel'] = $a['label'];
            $profile['traits']      = $a['traits'];
            $profile['domains']     = $a['domains'];
            $profile['quiz_ps']     = WorkAnimal::psScore(array_values($answers));
            // Fasa 1 (Lumina EDGE): survey menghasilkan status 'stated'.
            // Animal/quiz_ps kekal di belakang sehingga Fasa 3 (spider ganti radar).
            // R6: edge status lama tak digunakan lagi (guna edge_survey_raw + surveyScore).
            // Kekal observe untuk keserasian, dilindungi try.
            try { $profile['edge'] = Edge::observe($answers, Edge::items('set1')); } catch (\Throwable $e) { $profile['edge'] = []; }
            // R6: simpan jawapan mentah untuk surveyScore (5 domain).
            $profile['edge_survey_raw'] = array_values($answers);

            // Fasa 3 addendum: calon yang SUDAH ada evidence (datang daripada
            // resume) tidak perlu input evidence kedua. Bina semula blok EDGE
            // dengan panggilan servis yang SAMA seperti buildProfile(), kerana
            // potential_profile dibina sebelum quiz_ps wujud. Skills, readiness
            // dan match TIDAK dikira semula — hanya blok EDGE yang memang
            // menunggu data kuiz ini.
            if (! empty($profile['evidence_text'])) {
                $profile['potential_profile'] = (new \App\Services\PotentialProfileService())->build(
                    $profile['quiz_ps'],
                    $profile['evidence_text'],
                    $profile['skills'] ?? []
                );
                session()->set('profile', $profile);
                return redirect()->to(base_url('passport'));
            }

            session()->set('profile', $profile);
            return redirect()->to(base_url('onboard/input'));
        }
        return view('candidate/edge', [
            'title' => 'Lumina · Discover your work approach',
            'items' => Edge::itemsV2(),
        ]);
    }

    // ---------- Fasa 3: evidence input ----------
    public function input()
    {
        if ($this->request->getMethod() === 'POST') {
            $method  = $this->request->getPost('method');
            if ($method === 'guided') { return $this->buildGuided(); }
            $profile = session('profile') ?? [];
            $domain  = $profile['domains'][0] ?? 'Data';

            if ($method === 'transcript') {
                $text = self::SAMPLE_MYCSD; $verified = 1; $stated = [];
            } elseif ($method === 'fiveq') {
                $interest = $this->request->getPost('q_interest') ?: 'Data';
                $subject  = $this->request->getPost('q_subject') ?: '';
                $activity = $this->request->getPost('q_activity') ?: '';
                $text = trim("Interested in {$interest}. Strong in {$subject}. {$activity}");
                $stated = $this->subjectToSkills($subject);
                $domain = $this->normaliseDomain($interest);
                $verified = 0;
            } else { // paste
                $text = trim((string) $this->request->getPost('evidence_text'));
                $stated = []; $verified = 0;
            }

            $pName = trim((string) $this->request->getPost('p_name'));
            $this->buildProfile($text, $stated, $domain, $profile['animal'] ?? null, $verified, $pName ?: ($profile['name'] ?? null), [
                'programme'  => trim((string) $this->request->getPost('p_programme')) ?: null,
                'university' => trim((string) $this->request->getPost('p_university')) ?: null,
                'cgpa'       => trim((string) $this->request->getPost('p_cgpa')) ?: null,
                'study_year' => trim((string) $this->request->getPost('p_year')) ?: null,
            ]);
            // Strategic C3: brief "reveal" before continuing, so this path
            // feels consistent with Analyze Resume's inline AI reveal —
            // same eventual destination (/passport), same moment of
            // acknowledgement, instead of an instant, unexplained redirect.
            $updated = session('profile') ?? [];
            return view('candidate/reveal', [
                'title'       => 'Lumina · Reading your evidence',
                'skillCount'  => count($updated['skills'] ?? []),
                'animalLabel' => $updated['animalLabel'] ?? null,
            ]);
        }
        return view('candidate/input', [
            'title'  => 'Lumina · Build your portfolio',
            'sample' => self::SAMPLE_MYCSD,
            'personaEvidence' => [
                'aiman'  => ['text' => $this->personaResume('aiman'),  'pName' => 'Aiman Hakim',                'pProgramme' => 'BSc Information Technology',       'pUniversity' => 'Universiti Sains Malaysia',        'pYear' => 'Year 3', 'pCgpa' => '3.62'],
                'nurul'  => ['text' => $this->personaResume('nurul'),  'pName' => 'Nurul Aisyah binti Rahman',  'pProgramme' => 'BBA (Hons) Marketing',             'pUniversity' => 'Universiti Teknologi MARA (UiTM)', 'pYear' => 'Year 3', 'pCgpa' => '3.48'],
                'weijie' => ['text' => $this->personaResume('weijie'), 'pName' => 'Tan Wei Jie',                'pProgramme' => 'BEng (Hons) Electrical Engineering', 'pUniversity' => 'Universiti Teknologi Malaysia (UTM)', 'pYear' => 'Year 4', 'pCgpa' => '3.71'],
            ],
        ]);
    }

    // ---------- Fasa 3: Living Portfolio ----------
    public function passport()
    {
        // Fasa 3 (D18): jangan auto-load persona sample ke sesi kosong.
        // Aiman hanya melalui /start/sample atau demo mode yang jelas.
        $profile = session('profile');
        if (! $profile) { return redirect()->to(base_url('start')); }

        $svc  = new ScoreService();
        $cand = $this->buildSignal($profile);
        $role = $this->targetRoleFor($profile['target_domain'] ?? 'Data', $cand);

        $readiness = $svc->readiness($cand, $role);
        $match     = $svc->match($cand, $role);
        $risk      = $svc->risk($readiness['score']);

        return view('candidate/passport', [
            'title'     => 'Lumina · Living Portfolio',
            'profile'   => $profile,
            'readiness' => $readiness,
            'match'     => $match,
            'risk'      => $risk,
            'role'      => $role,
            'whyText'   => Explain::readiness($readiness),
            'potentialProfile' => $profile['potential_profile'] ?? null,
            // R6 (EDGE dua lapisan): survey + evidence coverage.
            'edgeSurvey'   => Edge::surveyScore($profile['edge_survey_raw'] ?? []),
            'edgeEvidence' => Edge::evidenceCoverage($profile['edge_skills_raw'] ?? []),
            'edgeQuotes'   => Edge::evidenceQuotes($profile['edge_skills_raw'] ?? [], $profile['evidence_text'] ?? ''),
            'edgeHas'      => ! empty($profile['edge_survey_raw']) || ! empty($profile['edge_skills_raw']),
        ]);
    }

    // ---------- Fasa 4: Career Compass ----------
    /** Fasa 4: calon pilih share EDGE evidence summary dengan employer (consent). */
    public function shareEdge()
    {
        $on = (int) $this->request->getGet('on') === 1;
        session()->set('edge_shared', $on);
        return $this->response->setJSON(['ok' => true, 'shared' => $on]);
    }

    public function compass()
    {
        // Fasa 3 (D18): tiada auto-load sample.
        $profile = session('profile');
        if (! $profile) { return redirect()->to(base_url('start')); }

        $svc  = new ScoreService();
        $cand = $this->buildSignal($profile);
        // Strategic B6: Potential Profile (B1/B2), used for "Strength to develop".
        $potentialProfile = $profile['potential_profile'] ?? null;

        $paths = [];
        foreach ($this->pathRoles($cand) as $role) {
            $r = $svc->readiness($cand, $role);
            $m = $svc->match($cand, $role);
            $traj = $this->trajectoryFor($svc, $cand, $role, $m['gap']);
            $extras = $this->growthExtras($potentialProfile, $traj, $role['title']);
            $paths[] = [
                'key'       => $role['key'],
                'title'     => $role['title'],
                'color'     => $role['color'],
                'colorHex'  => $role['hex'],
                'readiness' => $r['score'],
                'label'     => $m['label'],
                'match'     => $m['matchScore'],
                'gaps'      => array_map(fn ($c) => ['code' => $c, 'label' => $this->skillLabel($c)], $m['gap']),
                'plan'      => $this->planFor($m['gap']),
                'traj'      => $traj,
            ] + $extras;
        }
        usort($paths, fn ($a, $b) => $b['readiness'] <=> $a['readiness']);

        // Strategic B6: Chosen Pathway, if the candidate explored a career (B5).
        $chosenPath = null;
        $chosenKey  = $profile['chosen_career'] ?? null;
        if ($chosenKey) {
            $allRolesForChosen = \App\Libraries\Catalog::roles();
            if (isset($allRolesForChosen[$chosenKey])) {
                $cRole   = $allRolesForChosen[$chosenKey];
                $cR      = $svc->readiness($cand, $cRole);
                $cM      = $svc->match($cand, $cRole);
                $cTraj   = $this->trajectoryFor($svc, $cand, $cRole, $cM['gap']);
                $cExtras = $this->growthExtras($potentialProfile, $cTraj, $cRole['title']);
                $chosenPath = [
                    'key'       => $cRole['key'],
                    'title'     => $cRole['title'],
                    'color'     => $cRole['color'],
                    'colorHex'  => $cRole['hex'],
                    'readiness' => $cR['score'],
                    'label'     => $cM['label'],
                    'gaps'      => array_map(fn ($c) => ['code' => $c, 'label' => $this->skillLabel($c)], $cM['gap']),
                    'plan'      => $this->planFor($cM['gap']),
                    'traj'      => $cTraj,
                ] + $cExtras;
            }
        }

        return view('candidate/compass', [
            'title'   => 'Lumina · Career Compass',
            'profile' => $profile,
            'paths'   => $paths,
            // Strategic B5: full catalog for "Explore Another Career".
            'allRoles' => \App\Libraries\Catalog::roles(),
            // Strategic B6: Chosen Pathway comparison.
            'chosenPath' => $chosenPath,
        ]);
    }

    /** AJAX: recompute readiness for a path after adding skills (What-If). */
    public function whatif()
    {
        $profile = session('profile') ?? [];
        $cand    = $this->buildSignal($profile);
        $key     = (string) $this->request->getPost('role');
        $add     = $this->request->getPost('add') ?? [];
        $roles   = $this->pathRoles($cand);
        $role    = $roles[$key] ?? array_values($roles)[0];

        $svc = new ScoreService();
        $w   = $svc->whatIf($cand, $role, is_array($add) ? $add : []);
        return $this->response->setJSON($w);
    }

    /**
     * Career Explorer (Fasa B5 — Strategic B): compute fit against ANY role
     * in the full catalog, not just the 3 preset paths. Reuses buildSignal(),
     * planFor(), trajectoryFor(), skillLabel() and ScoreService::readiness()/
     * match() as-is — no new scoring logic. Additive: new route + method.
     */
    public function exploreCareer()
    {
        $key   = (string) $this->request->getPost('role');
        $roles = \App\Libraries\Catalog::roles();
        $role  = $roles[$key] ?? null;
        if (! $role) {
            return $this->response->setJSON(['error' => 'invalid_role']);
        }

        // Fasa 3 (D18): endpoint AJAX — pulangkan error, jangan auto-load sample.
        $profile = session('profile');
        if (! $profile) { return $this->response->setJSON(['error' => 'no_profile']); }

        $svc  = new ScoreService();
        $cand = $this->buildSignal($profile);
        // Strategic B6: Potential Profile (B1/B2), used for "Strength to develop".
        $potentialProfile = $profile['potential_profile'] ?? null;

        $readiness = $svc->readiness($cand, $role);
        $match     = $svc->match($cand, $role);
        $gap       = $match['gap'];
        $traj      = $this->trajectoryFor($svc, $cand, $role, $gap);
        $extras    = $this->growthExtras($potentialProfile, $traj, $role['title']);


        // Explorer-specific, positive-only labels — cosmetic remap only,
        // reuses the Protected Baseline match() label/thresholds as-is.
        $fitLabel = [
            'best'    => 'Ready Now',
            'growth'  => 'Reachable',
            'stretch' => 'Longer Path',
        ][$match['label']] ?? 'Reachable';

        // Remember the chosen career for later phases (e.g. B6 Growth Pathway).
        $profile['chosen_career'] = $key;
        session()->set('profile', $profile);

        // Strategic C5: Interview Prep for Career Explorer — updates whenever
        // the candidate explores a different career (chosen career changes).
        $interviewPrepExplore = $this->interviewPrep(
            array_map(fn ($c) => $this->skillLabel($c), $match['matched']),
            array_map(fn ($c) => $this->skillLabel($c), $gap),
            $role['title']
        );

        return $this->response->setJSON([
            'key'       => $role['key'],
            'title'     => $role['title'],
            'color'     => $role['color'],
            'colorHex'  => $role['hex'],
            'readiness' => $readiness['score'],
            'fitLabel'  => $fitLabel,
            'matched'   => array_map(fn ($c) => ['code' => $c, 'label' => $this->skillLabel($c)], $match['matched']),
            'gaps'      => array_map(fn ($c) => ['code' => $c, 'label' => $this->skillLabel($c)], $gap),
            'plan'      => $this->planFor($gap),
            'traj'      => $traj,
            'interview_prep' => $interviewPrepExplore,
        ] + $extras);
    }

    // ---------- Fasa 5: Smart Matching (candidate) ----------
    public function smatch()
    {
        // Fasa 3 (D18): tiada auto-load sample.
        $profile = session('profile');
        if (! $profile) { return redirect()->to(base_url('start')); }

        $svc  = new ScoreService();
        $cand = $this->buildSignal($profile);

        $opps = [];
        foreach (\App\Libraries\Catalog::roles() as $role) {
            $m = $svc->match($cand, $role);
            $matchedLabels = \App\Libraries\Catalog::labels($m['matched']);
            $gapLabels     = \App\Libraries\Catalog::labels($m['gap']);
            $opps[] = [
                'title'   => $role['title'],
                'company' => $role['company'],
                'location' => $role['location'],
                'salary'  => $role['salary'],
                'color'   => $role['color'],
                'match'   => $m['matchScore'],
                'label'   => $m['label'],
                'matched' => $matchedLabels,
                'gap'     => $gapLabels,
                'reason'  => \App\Libraries\Explain::match($m, $role['domain']),
                'interview_prep' => $this->interviewPrep($matchedLabels, $gapLabels, $role['title']),
            ];
        }
        usort($opps, fn ($a, $b) => $b['match'] <=> $a['match']);
        $opps = array_slice($opps, 0, 3);
        $display = ['Best fit', 'Growth fit', 'Stretch fit'];
        foreach ($opps as $i => &$o) { $o['fit'] = $display[$i] ?? 'Fit'; }
        unset($o);

        // Fasa 6.2 L4: jambatan Catalog -> employer_roles DB untuk JD penuh (3 opp sahaja).
        $rm = new \App\Models\EmployerRoleModel();
        foreach ($opps as $i => &$o) {
            $o['role_id'] = null; $o['full'] = null;
            try {
                $found = $rm->browse(['q' => $o['title']], 1, 0);
                if (! empty($found[0]['id'])) {
                    $o['role_id'] = (int) $found[0]['id'];
                    $o['full']    = $rm->fullRole($o['role_id']);
                }
            } catch (\Throwable $e) { $o['role_id'] = null; $o['full'] = null; }
        }
        unset($o);

        return view('candidate/match', [
            'title'   => 'Lumina · Smart Matching',
            'profile' => $profile,
            'opps'    => $opps,
        ]);
    }

    /**
     * Interview Prep (Fasa B7a — Strategic B): STAR-style questions built
     * from THIS candidate's actual matched skills and gaps — not generic.
     */
    private function interviewPrep(array $matched, array $gap, string $roleTitle): array
    {
        $questions = [];
        foreach (array_slice($matched, 0, 2) as $skill) {
            $questions[] = "Tell me about a time you used {$skill}. What was the situation, your action, and the result?";
        }
        if ($gap) {
            $questions[] = "How are you building your {$gap[0]} skills for a {$roleTitle} role?";
        }
        $questions[] = "Why are you interested in a {$roleTitle} role specifically?";
        return array_slice($questions, 0, 4);
    }

    public function placed()  { return $this->soon('Placed / Growing', 'Fasa 6', 'Your career keeps growing after you are hired.'); }

    private function soon($name, $phase, $desc) { return view('home/soon', compact('name', 'phase', 'desc') + ['title' => "Lumina · $name"]); }

    // ---------- Resume Analysis (v1 feature, simulated AI) ----------
    public function resume()
    {
        // Fasa 6.2: buka /resume = mula persona baharu. Reset medan
        // persona-specific (quiz_ps, animal, skills, evidence, identiti)
        // supaya persona baharu tidak warisi persona sebelumnya. Kekal stage.
        session()->set('profile', ['stage' => session('stage') ?? '19-22']);
        return view('candidate/resume', [
            'title' => 'Lumina · Resume Analysis',
            'personaResumes' => [
                'aiman'  => $this->personaResume('aiman'),
                'nurul'  => $this->personaResume('nurul'),
                'weijie' => $this->personaResume('weijie'),
            ],
        ]);
    }

    /**
     * AJAX (lightweight, no persist): read the pasted resume just enough to
     * detect a name + a few highlight clauses, so the candidate can confirm
     * or correct their profile BEFORE the full AI analysis runs.
     */
    public function resumePreview()
    {
        $text = trim((string) $this->request->getPost('resume_text'));
        if ($text === '') return $this->response->setJSON(['error' => 'empty']);

        $name   = $this->extractName($text);
        $parser = new \App\Services\ResumeParserService();
        $highlights = array_slice(array_values(array_unique(array_merge(
            $parser->detectLeadership($text),
            $parser->detectProjects($text)
        ))), 0, 4);

        return $this->response->setJSON(['name' => $name, 'highlights' => $highlights]);
    }

    /**
     * Deterministic name detector (no external AI): looks at the first few
     * lines for something that reads like "Firstname Lastname", else a
     * "Name: ..." label. Returns '' if nothing confident is found — the
     * candidate can just type it in on the confirm step.
     */
    private function extractName(string $text): string
    {
        $lines = preg_split('/\r\n|\r|\n/', trim($text));
        $stop = ['resume', 'curriculum vitae', 'cv', 'objective', 'summary', 'profile', 'contact',
                 'email', 'phone', 'address', 'experience', 'education', 'skills', 'final-year', 'university'];

        foreach (array_slice($lines, 0, 3) as $line) {
            $line = trim($line, " \t\-–•·");
            if ($line === '' || mb_strlen($line) > 40) continue;
            $lc = strtolower($line);
            $skip = false;
            foreach ($stop as $sw) { if (str_contains($lc, $sw)) { $skip = true; break; } }
            if ($skip) continue;
            if (preg_match('/^([A-Z][a-zA-Z\'\-]+(?:\s+(?:binti|bin|a\/l|a\/p|al|[A-Z][a-zA-Z\'\-]+)){1,4})$/', $line, $m)) {
                return $m[1];
            }
        }
        if (preg_match('/name\s*[:\-]\s*([A-Za-z\'\-]+(?:\s+[A-Za-z\'\-]+){1,3})/i', $text, $m)) {
            return trim($m[1]);
        }
        return '';
    }

    /** AJAX: analyse pasted resume text, build profile, persist, return JSON. */
    public function resumeAnalyze()
    {
        $text = trim((string) $this->request->getPost('resume_text'));
        if ($text === '') return $this->response->setJSON(['error' => 'empty']);
        // Fasa 6.2: analyze resume baharu = profil fresh. Buang medan persona
        // sebelumnya (quiz_ps, animal, identiti) supaya tukar persona tidak warisi
        // data lama. Kekalkan stage/role sahaja.
        $keep = ['stage' => session('profile')['stage'] ?? (session('stage') ?? '19-22')];
        session()->set('profile', $keep);
        $confirmedName = trim((string) $this->request->getPost('name'));
        if ($confirmedName === '') { $confirmedName = $this->extractName($text); }

        $svc       = new ScoreService();
        $parser    = new \App\Services\ResumeParserService();
        $explained = $svc->inferSkillsExplained($text, []);

        // ---- Field of study: read what the candidate actually STUDIED first.
        // This is a stronger, more trustworthy signal than generic soft-skill
        // keywords (communication, teamwork, ...) that appear in almost every
        // resume regardless of field. Falls back to skill-keyword majority
        // vote only when no degree/programme line is detected.
        $degree = $parser->extractFieldOfStudy($text);
        $domain = $this->guessDomain(array_keys($explained), $degree['domain'] ?? null);

        // persist profile (session) so the user can continue into Compass/Match
        $this->buildProfile(
            $text, [], $domain, session('profile')['animal'] ?? null, 0,
            $confirmedName ?: (session('profile')['name'] ?? null),
            [
                'programme'  => $this->extractProgrammeLine($text, $degree['raw'] ?? null),
                'university' => $this->universityLabel($this->detectUniversity($text)),
                'cgpa'       => $this->extractCgpa($text),
                'study_year' => $this->extractStudyYear($text),
            ]
        );
        // Ground initial matching in skills GAINED THROUGH THE PROGRAMME
        // (e.g. Chemical Engineering -> chemical_processing, process_safety),
        // not just whatever soft-skill keywords happen to appear in the
        // activities/leadership text. Additive only — never overrides an
        // already explicitly-detected skill.
        $this->injectCoreSkills($degree['coreSkills'] ?? []);
        $cand = $this->buildSignal(session('profile'));

        // top role matches
        $matches = [];
        foreach (\App\Libraries\Catalog::roles() as $key => $role) {
            $m = $svc->match($cand, $role);
            $matches[] = ['key' => $key, 'title' => $role['title'], 'company' => $role['company'],
                          'domain' => $role['domain'], 'color' => $role['hex'],
                          'match' => $m['matchScore'], 'label' => $m['label'],
                          'gap' => \App\Libraries\Catalog::labels($m['gap'])];
        }
        usort($matches, fn ($a, $b) => $b['match'] <=> $a['match']);

        // If we detected a clear field of study, pin the best-fitting role in
        // that field to the #1 spot — a Chemical Engineering degree should
        // outrank a generic Business role even when the Business role scores
        // marginally higher purely on generic soft-skill overlap.
        if (! empty($degree['domain'])) {
            $sameField = array_values(array_filter($matches, fn ($x) => $x['domain'] === $degree['domain']));
            if ($sameField) {
                $pinned = $sameField[0];
                $rest   = array_values(array_filter($matches, fn ($x) => $x['key'] !== $pinned['key']));
                $matches = array_merge([$pinned], $rest);
            }
        }
        $top = array_slice($matches, 0, 3);

        // readiness vs the best-fit role — prefer the exact role hinted by the
        // detected degree, else the best role within the detected domain,
        // else the global best match.
        $bestRoleKey = (! empty($degree['role']) && isset(\App\Libraries\Catalog::roles()[$degree['role']]))
            ? $degree['role']
            : $this->bestRoleKey($cand, $svc, $degree['domain'] ?? null);
        $bestRole  = \App\Libraries\Catalog::role($bestRoleKey);
        $bestM     = $svc->match($cand, $bestRole);
        $readiness = $svc->readiness($cand, $bestRole);
        $band      = $svc->risk($readiness['score']);

        $skillOut = [];
        foreach ($cand['skills'] as $code => $s) {
            $skillOut[] = [
                'label'  => \App\Libraries\Catalog::label($code),
                'source' => $s['source'] ?? 'inferred',
                'conf'   => round(($s['confidence'] ?? 0.6) * 100),
                'from'   => $s['from'] ?? (($s['source'] ?? '') === 'programme' ? ('from your field of study: ' . ($degree['raw'] ?? '')) : null),
                'evidence_label' => $s['evidence_label'] ?? (($s['source'] ?? '') === 'stated' ? 'Stated' : 'Inferred'),
            ];
        }

        // detect a university named in the resume (optional display)
        $foundUni = $this->detectUniversity($text);

        // benchmark this readiness against the cohort (same field)
        $cohort = $this->benchmark($svc, $domain, $readiness['score']);

        // ---- Fasa 2: richer extracted profile + recommendations ----
        $rec    = new \App\Services\RecommendationService();
        $projects    = $parser->detectProjects($text);
        $leadership  = $parser->detectLeadership($text);
        $cluster     = $parser->careerCluster($domain);
        $animal      = $parser->animalFromEvidence($cand['skills'], $text);
        $internships = $rec->internships($domain);
        $feedback    = $rec->feedback($text, $cand['skills'], $readiness['score'], $projects, $leadership);
        $nextAction  = $rec->nextAction($band, $bestM['gap'], $bestM['matched']);
        $courses     = $rec->microCourses($bestM['gap']);
        $resumeCoach = $rec->resumeCoach(
            $text, $cand['skills'], $projects, $leadership,
            $bestM['gap'], $bestRole['title'] ?? null, $readiness['score']
        );
        // Strategic C2: reuses $projects/$leadership already computed above.
        $consistencyFlags = (new \App\Services\ProfileConsistencyService())->check(
            $cand['skills'], $projects, $leadership, session('profile')['potential_profile'] ?? null
        );
        // Strategic C5: Interview Prep for /resume, reuses interviewPrep() from B7a.
        $interviewPrepResume = $this->interviewPrep(
            \App\Libraries\Catalog::labels($bestM['matched']),
            \App\Libraries\Catalog::labels($bestM['gap']),
            $bestRole['title'] ?? 'this role'
        );

        // ---- Lumina Graph: enrich + learn ----
        $tax        = new \App\Services\TaxonomyService();
        $detCodes   = array_keys($cand['skills']);
        $graph      = $tax->enrich($detCodes, '', $domain);
        $graphLearn = $tax->learn($detCodes, $text, '', $domain);
        $graphStats = $tax->stats();
        $novel      = $tax->extractNovel($text);
        $graphNew   = $tax->learnNovel($novel, $domain, $detCodes, '');
        $tax->reinforce(array_merge($detCodes, array_column($novel, 'code')));
        $graphStats = $tax->stats();

        // ---- Fasa 2: persist to DB (demo-safe: never breaks the demo) ----
        $savedId = null;
        try {
            $sk   = session_id();
            $name = session('profile')['name'] ?? 'You';
            $savedId = (new \App\Models\ResumeAnalysisModel())->insert([
                'session_key'        => $sk,
                'source'             => 'resume',
                'name'               => $name,
                'raw_text'           => $text,
                'target_domain'      => $domain,
                'career_cluster'     => $cluster,
                'readiness'          => $readiness['score'],
                'employability_band' => $band,
                'animal_primary'     => $animal['primary']['id'],
                'animal_secondary'   => $animal['secondary']['id'],
                'animal_growth'      => $animal['growth']['id'],
                'skills_json'        => json_encode($skillOut),
                'projects_json'      => json_encode($projects),
                'leadership_json'    => json_encode($leadership),
                'feedback_json'      => json_encode($feedback),
                'next_action'        => $nextAction,
            ], true);
            (new \App\Models\CandidateProfileModel())->insert([
                'analysis_id'   => $savedId,
                'session_key'   => $sk,
                'name'          => $name,
                'stage'         => session('stage') ?? '19-22',
                'target_domain' => $domain,
                'animal'        => $animal['primary']['id'],
                'verified'      => 0,
                'evidence_text' => $text,
                'skills_json'   => json_encode(array_keys($cand['skills'])),
                'readiness'     => $readiness['score'],
            ]);
        } catch (\Throwable $e) {
            log_message('error', 'Lumina persist failed: ' . $e->getMessage());
        }

        return $this->response->setJSON([
            'skills'     => $skillOut,
            'readiness'  => $readiness['score'],
            'matches'    => $top,
            'domain'     => $domain,
            'field'      => $this->fieldName($domain) . (! empty($degree['raw']) ? ' · Field of study detected: ' . $degree['raw'] : ''),
            'university' => $foundUni,
            'cohort'     => $cohort,
            'name'       => session('profile')['name'] ?? 'You',
            // ---- Fasa 2 additions ----
            'career_cluster' => $cluster,
            'band'           => $band,
            'projects'       => $projects,
            'leadership'     => $leadership,
            'animal'         => $animal,
            'internships'    => $internships,
            'feedback'       => $feedback,
            'next_action'       => $nextAction,
            'courses'           => $courses,
            'resume_coach'      => $resumeCoach,
            'consistency_flags' => $consistencyFlags,
            'interview_prep'    => $interviewPrepResume,
            'saved'             => (bool) $savedId,
            'saved_id'       => $savedId,
            'graph_related'  => $graph['related'],
            'graph_added'    => count($graphLearn['added_skills']),
            'graph_stats'    => $graphStats,
            'graph_new_skills' => $graphNew,
            // Fasa 2c (EDGE): Review suggestions + Add cadangan + footnote.
            'edge_suggestions' => Edge::suggestions(session('profile')['edge'] ?? []),
            'edge_add'         => Edge::addSuggestions($this->edgePersona()),
            'edge_signals'     => $this->edgeSignalNames(),
            'edge_hints'       => Edge::editHints(),
            'edge_footnote'    => 'Lumina links parts of your CV to work signals. These are early suggestions you can keep, edit, remove, or add to. Nothing here is a fixed judgement.',
        ]);
    }

    /** Where does this readiness sit among cohort students of the same domain? */
    private function benchmark(ScoreService $svc, string $domain, int $myReadiness): array
    {
        try {
            $peers = \Config\Database::connect()->table('students')
                ->select('evidence_text, has_resume')->where('target_domain', $domain)
                ->get()->getResultArray();
        } catch (\Throwable $e) { $peers = []; }

        $n = count($peers); $below = 0; $sum = 0;
        foreach ($peers as $p) {
            $pc = $svc->signal($p['evidence_text'] ?? '', [], (int) ($p['has_resume'] ?? 0), $domain);
            $pr = $svc->readiness($pc, \App\Libraries\Catalog::role($this->bestRoleKey($pc, $svc, $domain)))['score'];
            $sum += $pr;
            if ($pr < $myReadiness) $below++;
        }
        return [
            'domain'     => $domain,
            'size'       => $n,
            'percentile' => $n ? (int) round(100 * $below / $n) : 0,
            'avg'        => $n ? (int) round($sum / $n) : 0,
            'you'        => $myReadiness,
        ];
    }

    /**
     * Best matching role key. If $domainHint is given, restricts the search
     * to roles in that domain first (falls back to a global search only if
     * that domain has no roles at all) — so a detected field of study keeps
     * the readiness/gap calculation anchored to the right domain.
     */
    private function bestRoleKey(array $cand, ScoreService $svc, ?string $domainHint = null): string
    {
        $roles = \App\Libraries\Catalog::roles();

        if ($domainHint) {
            $inDomain = array_filter($roles, fn ($r) => $r['domain'] === $domainHint);
            if ($inDomain) {
                $bestKey = array_key_first($inDomain); $bestScore = -1;
                foreach ($inDomain as $key => $role) {
                    $m = $svc->match($cand, $role);
                    if ($m['matchScore'] > $bestScore) { $bestScore = $m['matchScore']; $bestKey = $key; }
                }
                return $bestKey;
            }
        }

        $bestKey = 'data_analyst'; $bestScore = -1;
        foreach ($roles as $key => $role) {
            $m = $svc->match($cand, $role);
            if ($m['matchScore'] > $bestScore) { $bestScore = $m['matchScore']; $bestKey = $key; }
        }
        return $bestKey;
    }

    private function fieldName(string $domain): string
    {
        return [
            'Data'                     => 'Data, Analytics & Computing',
            'Engineering'              => 'Engineering & Technology',
            'Design'                   => 'Design & Creative',
            'Business'                 => 'Business, Finance & Communication',
            'Education'                => 'Education & Training',
            'Arts & Humanities'        => 'Arts, Culture & Humanities',
            'Social Sciences'         => 'Social Sciences & Public Affairs',
            'Natural Sciences'        => 'Natural Sciences & Research',
            'Agriculture & Veterinary' => 'Agriculture & Veterinary Sciences',
            'Health & Welfare'        => 'Health & Welfare',
            'Services'                 => 'Hospitality, Tourism & Services',
        ][$domain] ?? $domain;
    }

    /**
     * $override (from a detected field of study) always wins when present —
     * what the candidate studied is a stronger signal than skill-keyword
     * counting. Falls back to majority-vote across skill buckets otherwise
     * (not first-match-wins: a single stray "analysis" mention should not
     * override a resume full of engineering signals). Covers all 11 domains.
     */
    private function guessDomain(array $codes, ?string $override = null): string
    {
        if ($override) return $override;

        $buckets = [
            'Design'      => ['ui_ux', 'figma', 'graphic_design'],
            'Data'        => ['sql', 'python', 'data_analysis', 'dashboarding', 'statistics', 'machine_learning'],
            'Engineering' => ['software', 'cloud', 'java', 'javascript', 'api',
                'mechanical_design', 'cad', 'fea', 'manufacturing', 'six_sigma',
                'aerodynamics', 'aircraft_systems', 'avionics', 'structural_engineering',
                'circuit_design', 'plc', 'electrical_schematics', 'embedded', 'robotics', 'control_systems',
                'process_safety', 'chemical_processing', 'project_planning'],
            'Education'   => ['lesson_planning', 'classroom_mgmt', 'curriculum_design', 'training_design'],
            'Arts & Humanities' => ['translation', 'performance', 'stage_presence', 'archival_work', 'creativity'],
            'Social Sciences'  => ['interviewing', 'policy_analysis', 'case_mgmt', 'counselling'],
            'Natural Sciences' => ['lab_techniques', 'quality_control', 'risk_modeling', 'scientific_writing'],
            'Agriculture & Veterinary' => ['crop_science', 'field_research', 'sustainability', 'animal_care', 'aquaculture'],
            'Health & Welfare' => ['clinical_skills', 'patient_care', 'pharmacology', 'rehabilitation', 'public_health'],
            'Services'    => ['hospitality_ops', 'event_planning', 'logistics'],
        ];
        $best = 'Business'; $bestCount = 0;
        foreach ($buckets as $dom => $set) {
            $count = count(array_intersect($codes, $set));
            if ($count > $bestCount) { $bestCount = $count; $best = $dom; }
        }
        return $best;
    }

    private function roleKeyForDomain(string $d): string
    {
        return match ($d) { 'Engineering' => 'backend_engineer', 'Business' => 'product_exec', default => 'data_analyst' };
    }

    // ================= helpers =================

    /**
     * Merge skills typically GAINED through the candidate's declared
     * programme into their session profile (tagged source='programme').
     * These ground the initial job-description matching; they are additive
     * and never override an already-detected, explicitly-written skill.
     */
    private function injectCoreSkills(array $codes): void
    {
        if (! $codes) return;
        $profile = session('profile') ?? [];
        foreach ($codes as $code) {
            if (! isset($profile['skills'][$code])) {
                $profile['skills'][$code] = ['confidence' => 0.6, 'source' => 'programme'];
            }
        }
        session()->set('profile', $profile);
    }

    private function buildProfile(string $text, array $stated, string $domain, ?string $animal, int $verified, ?string $name, array $extra = []): void
    {
        $svc = new ScoreService();
        // Strategic B3: explained variant adds 'from' (trigger word); each
        // skill is then labelled with its canonical evidence status.
        // Additive — readiness()/match() only read 'confidence'/'source'.
        $skills = $svc->inferSkillsExplained($text, $stated);
        // Fasa 2 (EDGE): infer signal daripada evidence RAW (sebelum jadi label).
        $edgeInferred = Edge::inferFromEvidence($skills);
        // R6: simpan skills RAW (ada 'from' quote) untuk evidenceCoverage + card evidence list.
        $edgeSkillsRaw = $skills;
        $skills = (new \App\Services\EvidenceCheckService())->label($skills, $verified, $text);
        $profile = session('profile') ?? [];
        $profile = array_merge($profile, [
            'name'          => $name ?: ($profile['name'] ?? null),
            'stage'         => session('stage') ?? '19-22',
            'animal'        => $animal ?? ($profile['animal'] ?? null),
            'evidence_text' => $text,
            'skills'        => $skills,
            'edge'          => Edge::merge(session('profile')['edge'] ?? [], $edgeInferred),
            'edge_skills_raw' => $edgeSkillsRaw,
            // B1: auto-isi survey approach untuk persona demo (jika calon belum jawab).
            'edge_survey_raw' => (! empty(session('profile')['edge_survey_raw']))
                ? session('profile')['edge_survey_raw']
                : (($dp = $this->edgePersonaFromName($name ?: '')) !== 'self' ? Edge::demoResponses($dp) : []),
            'verified'      => $verified,
            'target_domain' => $this->normaliseDomain($domain),
            // Fasa 3 (L5): medan identiti untuk header digital-CV.
            // Hanya ditetapkan bila pemanggil benar-benar tahu — tidak pernah direka.
            'programme'     => $extra['programme']  ?? ($profile['programme']  ?? null),
            'university'    => $extra['university'] ?? ($profile['university'] ?? null),
            'cgpa'          => $extra['cgpa']       ?? ($profile['cgpa']       ?? null),
            'study_year'    => $extra['study_year'] ?? ($profile['study_year'] ?? null),
            'last_updated'  => date('j M Y'),
        ]);

        // Fasa 3 (K5-a): label datang daripada hasil Work Animal sedia ada,
        // tidak pernah hardcode — jadi laluan kuiz dan sample tidak boleh bercanggah.
        if (! empty($profile['animal'])) {
            $wa = \App\Libraries\WorkAnimal::get($profile['animal']);
            $profile['animalLabel'] = $wa['label'];
            $profile['traits']      = $wa['traits'];
            $profile['domains']     = $wa['domains'];
        }

        $profile['potential_profile'] = (new \App\Services\PotentialProfileService())->build(
            $profile['quiz_ps'] ?? [],
            $text,
            $skills
        );

        // Strategic C2: Profile Consistency Check — additive, reuses
        // ResumeParserService detection already used elsewhere.
        $parser = new \App\Services\ResumeParserService();
        $profile['consistency_flags'] = (new \App\Services\ProfileConsistencyService())->check(
            $skills,
            $parser->detectProjects($text),
            $parser->detectLeadership($text),
            $profile['potential_profile']
        );

        session()->set('profile', $profile);
    }

    /**
     * Fasa 3 bug fix — university detection.
     * Sebelum ini: stripos() substring scan, jadi "community" -> MMU dan
     * apa-apa perkataan mengandungi "um" -> UM. Sekarang: nama penuh dahulu,
     * kemudian singkatan dengan sempadan perkataan. Display sahaja — tiada
     * kesan pada skor, formula atau taxonomy.
     */
    private function detectUniversity(string $text): ?string
    {
        $full = [
            'universiti sains malaysia'         => 'USM',
            'universiti kebangsaan malaysia'    => 'UKM',
            'universiti putra malaysia'         => 'UPM',
            'universiti teknologi malaysia'     => 'UTM',
            'universiti teknologi mara'         => 'UiTM',
            'universiti utara malaysia'         => 'UUM',
            'international islamic university'  => 'IIUM',
            'universiti malaysia sabah'         => 'UMS',
            'universiti malaysia sarawak'       => 'UNIMAS',
            'universiti malaysia terengganu'    => 'UMT',
            'universiti pendidikan sultan idris'=> 'UPSI',
            'universiti sains islam malaysia'   => 'USIM',
            'universiti malaysia kelantan'      => 'UMK',
            'universiti tun hussein onn'        => 'UTHM',
            'universiti teknikal malaysia'      => 'UTeM',
            'universiti malaysia pahang'        => 'UMP',
            'universiti malaysia perlis'        => 'UniMAP',
            'multimedia university'             => 'MMU',
            'universiti teknologi petronas'     => 'UTP',
            'universiti tenaga nasional'        => 'UNITEN',
            'asia pacific university'           => 'APU',
            'universiti malaya'                 => 'UM',
            'university of malaya'              => 'UM',
            'taylor'                            => 'Taylor',
            'sunway'                            => 'Sunway',
            'ucsi'                              => 'UCSI',
            'monash'                            => 'Monash',
            'nottingham'                        => 'Nottingham',
            'xiamen'                            => 'Xiamen',
            'heriot'                            => 'Heriot',
        ];
        $lc = mb_strtolower($text);
        foreach ($full as $needle => $code) {
            if (str_contains($lc, $needle)) return $code;
        }
        $abbr = ['USM','UKM','UPM','UTM','UiTM','UUM','IIUM','UNIMAS','UMS','UMT','UPSI','USIM','UMK','UTHM','UTeM','UniMAP','UMP','MMU','UTP','UNITEN','UCSI','APU','UM'];
        foreach ($abbr as $a) {
            if (preg_match('/\b' . preg_quote($a, '/') . '\b/i', $text)) return $a;
        }
        return null;
    }

    /** Kod universiti -> nama penuh untuk paparan CV. Display sahaja. */
    private function universityLabel(?string $code): ?string
    {
        if (! $code) return null;
        $map = [
            'USM' => 'Universiti Sains Malaysia', 'UKM' => 'Universiti Kebangsaan Malaysia',
            'UPM' => 'Universiti Putra Malaysia', 'UTM' => 'Universiti Teknologi Malaysia',
            'UiTM' => 'Universiti Teknologi MARA', 'UUM' => 'Universiti Utara Malaysia',
            'IIUM' => 'International Islamic University Malaysia', 'UMS' => 'Universiti Malaysia Sabah',
            'UNIMAS' => 'Universiti Malaysia Sarawak', 'UMT' => 'Universiti Malaysia Terengganu',
            'UPSI' => 'Universiti Pendidikan Sultan Idris', 'USIM' => 'Universiti Sains Islam Malaysia',
            'UMK' => 'Universiti Malaysia Kelantan', 'UTHM' => 'Universiti Tun Hussein Onn Malaysia',
            'UTeM' => 'Universiti Teknikal Malaysia Melaka', 'UMP' => 'Universiti Malaysia Pahang',
            'UniMAP' => 'Universiti Malaysia Perlis', 'MMU' => 'Multimedia University',
            'UTP' => 'Universiti Teknologi PETRONAS', 'UNITEN' => 'Universiti Tenaga Nasional',
            'APU' => 'Asia Pacific University', 'UM' => 'Universiti Malaya',
        ];
        return $map[$code] ?? $code;
    }

    /**
     * Fasa 3 (D19) — programme line untuk paparan CV.
     * extractFieldOfStudy() memulangkan kunci peta ("Information Technology"),
     * bukan baris resume. Kaedah ini membaca kelayakan yang BENAR-BENAR
     * ditulis dalam teks ("BSc Information Technology"). Jika tiada kelayakan
     * ditulis, fallback kepada field yang dikesan — kita TIDAK PERNAH mereka
     * "BSc" yang tidak wujud dalam teks calon.
     * Display sahaja: parser, detection rule dan scoring tidak disentuh.
     */
    private function extractProgrammeLine(string $text, ?string $fallback): ?string
    {
        $qual = '(?:B\.?Sc|B\.?A|B\.?Eng|B\.?B\.?A|B\.?I\.?T|B\.?Tech|B\.?Com|M\.?Sc|M\.?B\.?A|M\.?A|Bachelor(?:\x27s)?(?:\s+of\s+[A-Za-z]+)?|Diploma(?:\s+in)?|Foundation(?:\s+in)?|Ijazah)';
        if (preg_match('/\b(' . $qual . '\s+[A-Za-z][A-Za-z&\s\-]{2,48}?)\s*(?=[,\x{00B7}\r\n]|$)/u', $text, $m)) {
            $line = trim(preg_replace('/\s+/', ' ', $m[1]));
            if (mb_strlen($line) >= 5) return $line;
        }
        return $fallback;
    }

    /** Study year yang dinyatakan dalam teks calon sendiri. Display sahaja. */
    private function extractStudyYear(string $text): ?string
    {
        if (preg_match('/\bYear\s*([1-6])\b/i', $text, $m)) return 'Year ' . $m[1];
        return null;
    }

    /** CGPA yang dinyatakan dalam teks. Display sahaja — tidak pernah masuk scoring. */
    private function extractCgpa(string $text): ?string
    {
        if (preg_match('/\bC?GPA\b\s*[:\-]?\s*([0-4](?:\.\d{1,2})?)/i', $text, $m)) {
            return $m[1];
        }
        return null;
    }

    private function buildSignal(array $profile): array
    {
        $t = strtolower($profile['evidence_text'] ?? '');
        $projects   = substr_count($t, 'project') + substr_count($t, 'app') + substr_count($t, 'built');
        $activities = (int) (str_contains($t, 'club') || str_contains($t, 'treasurer'))
                    + (int) str_contains($t, 'volunteer')
                    + (int) (str_contains($t, 'led') || str_contains($t, 'president'));
        return [
            'skills'     => $profile['skills'] ?? [],
            'top_domain' => $profile['target_domain'] ?? 'Data',
            'verified'   => $profile['verified'] ?? 0,
            'projects'   => max(1, $projects),
            'activities' => max(1, $activities),
            'pace'       => 'Steady',
        ];
    }

    /** Best-fitting role for a domain, chosen dynamically from the shared Catalog (not hardcoded). */
    private function targetRoleFor(string $domain, ?array $cand = null): array
    {
        $domain = $this->normaliseDomain($domain);
        $inDomain = array_values(array_filter(\App\Libraries\Catalog::roles(), fn ($r) => $r['domain'] === $domain));
        $best = $inDomain[0] ?? null;
        if ($cand && count($inDomain) > 1) {
            $svc = new ScoreService(); $bestScore = -1;
            foreach ($inDomain as $r) {
                $m = $svc->match($cand, $r)['matchScore'];
                if ($m > $bestScore) { $bestScore = $m; $best = $r; }
            }
        }
        if (! $best) {
            return ['title' => 'Data Analyst', 'domain' => 'Data', 'required' => ['sql', 'dashboarding', 'python', 'data_analysis'], 'color' => 'var(--indigo)'];
        }
        return ['title' => $best['title'], 'domain' => $best['domain'], 'required' => $best['required'], 'color' => $best['color']];
    }

    /**
     * Pass any of the 11 valid Lumina domains through unchanged (case-insensitive).
     * Keeps a few legacy aliases for backward compatibility with older callers
     * (fiveq/guided flows that still say "Research", "Software", "Creative").
     * Anything unrecognised falls back to Business (broadest catch-all domain).
     */
    private function normaliseDomain(string $d): string
    {
        $d = trim($d);
        foreach (self::VALID_DOMAINS as $v) {
            if (strcasecmp($d, $v) === 0) return $v;
        }
        $d2 = ucfirst(strtolower($d));
        if (in_array($d2, ['Research'], true)) return 'Data';
        if (in_array($d2, ['Software', 'Tech'], true)) return 'Engineering';
        if (in_array($d2, ['Creative'], true)) return 'Design';
        return 'Business';
    }

    private function subjectToSkills(string $subject): array
    {
        $s = strtolower($subject); $out = [];
        if (str_contains($s, 'math') || str_contains($s, 'data'))      $out[] = 'data_analysis';
        if (str_contains($s, 'comput') || str_contains($s, 'program')) $out[] = 'software';
        if (str_contains($s, 'business') || str_contains($s, 'commun')) $out[] = 'communication';
        return $out;
    }

    // ---------- Fasa 3: guided No-Resume builder ----------
    private function buildGuided()
    {
        $r = $this->request;
        $programme  = trim((string) $r->getPost('g_programme'));
        $stage      = trim((string) $r->getPost('g_stage')) ?: (session('stage') ?? '19-22');
        $cgpaRaw    = trim((string) $r->getPost('g_cgpa'));
        $activities = trim((string) $r->getPost('g_activities'));
        $leadership = trim((string) $r->getPost('g_leadership'));
        $projects   = trim((string) $r->getPost('g_projects'));
        $tools      = trim((string) $r->getPost('g_tools'));
        $comps      = trim((string) $r->getPost('g_competitions'));
        $intern     = trim((string) $r->getPost('g_internship')) ?: 'none';
        $interest   = trim((string) $r->getPost('g_interest')) ?: 'Data';
        $prefRole   = trim((string) $r->getPost('g_role'));
        $ws1        = trim((string) $r->getPost('g_ws1'));
        $ws2        = trim((string) $r->getPost('g_ws2'));

        // assemble evidence text from the guided answers
        $parts = [];
        if ($programme)  $parts[] = "Studying {$programme}.";
        if ($leadership) $parts[] = $leadership . ($activities ? " of {$activities}." : ".");
        elseif ($activities) $parts[] = "Active in {$activities}.";
        if ($projects)   $parts[] = $projects . ".";
        if ($tools)      $parts[] = "Tools: {$tools}.";
        if ($comps)      $parts[] = "Competed in {$comps}.";
        if ($intern === 'completed') $parts[] = "Completed an internship.";
        elseif ($intern === 'ongoing') $parts[] = "Currently doing an internship.";
        $parts[] = "Interested in {$interest}" . ($prefRole ? " ({$prefRole})." : ".");
        if ($ws1) $parts[] = $ws1 . ".";
        if ($ws2) $parts[] = "I want impact through " . $ws2 . ".";
        $text = trim(implode(' ', $parts));

        $stated = array_values(array_unique(array_merge(
            $this->toolsToSkills($tools),
            $this->subjectToSkills($programme . ' ' . $interest)
        )));

        // field of study from the stated programme name wins over the loose "interest" pick
        $parserFos = new \App\Services\ResumeParserService();
        $fos       = $parserFos->extractFieldOfStudy($programme);
        $domain    = $fos['domain'] ?? $this->normaliseDomain($interest);

        session()->set('stage', $stage);
        $verified = $intern === 'completed' ? 1 : 0;

        $this->buildProfile($text, $stated, $domain, session('profile')['animal'] ?? null, $verified, null, [
            'programme' => $programme ?: null,
            'cgpa'      => is_numeric($cgpaRaw) ? $cgpaRaw : null,
        ]);
        $this->injectCoreSkills($fos['coreSkills'] ?? []);
        $cand = $this->buildSignal(session('profile'));

        $svc         = new ScoreService();
        $bestRoleKey = (! empty($fos['role']) && isset(\App\Libraries\Catalog::roles()[$fos['role']]))
            ? $fos['role']
            : $this->bestRoleKey($cand, $svc, $domain);
        $bestRole  = \App\Libraries\Catalog::role($bestRoleKey);
        $bestM     = $svc->match($cand, $bestRole);
        $readiness = $svc->readiness($cand, $bestRole);
        $band      = $svc->risk($readiness['score']);

        $parser = new \App\Services\ResumeParserService();
        $rec    = new \App\Services\RecommendationService();
        $nrb    = new \App\Services\NoResumeProfileBuilderService();

        $animal = $parser->animalFromEvidence($cand['skills'], $text);

        $skillsOut = [];
        foreach ($cand['skills'] as $code => $s) {
            $skillsOut[] = ['label' => \App\Libraries\Catalog::label($code),
                            'source' => $s['source'] ?? 'inferred',
                            'conf' => round((($s['confidence'] ?? 1)) * 100)];
        }

        $resumeDraft = $nrb->resumeDraft([
            'name' => 'You', 'programme' => $programme, 'stage' => $stage, 'cgpa' => $cgpaRaw,
            'activities' => $activities, 'leadership' => $leadership, 'projects' => $projects,
            'tools' => $tools, 'competitions' => $comps, 'internship' => $intern,
            'interest' => $interest, 'role' => $prefRole,
        ], array_keys($cand['skills']), $domain);

        $firstProject  = $nrb->firstProject($domain, $bestM['gap']);
        $activitiesRec = $nrb->activities($domain);
        $courses       = $rec->microCourses($bestM['gap']);
        $nextAction    = $rec->nextAction($band, $bestM['gap'], $bestM['matched']);
        $cluster       = $parser->careerCluster($domain);

        // ---- Lumina Graph: enrich + learn ----
        $tax        = new \App\Services\TaxonomyService();
        $detCodes   = array_keys($cand['skills']);
        $graph      = $tax->enrich($detCodes, $programme, $domain);
        $tax->learn($detCodes, $text, $programme, $domain);
        $graphStats = $tax->stats();
        $novel      = $tax->extractNovel($text);
        $graphNew   = $tax->learnNovel($novel, $domain, $detCodes, $programme);
        $tax->reinforce(array_merge($detCodes, array_column($novel, 'code')));
        $graphStats = $tax->stats();

        // persist (demo-safe)
        $savedId = null;
        try {
            $sk   = session_id();
            $cgpa = is_numeric($cgpaRaw) ? (float) $cgpaRaw : null;
            $savedId = (new \App\Models\ResumeAnalysisModel())->insert([
                'session_key' => $sk, 'source' => 'no_resume', 'name' => 'You', 'raw_text' => $text,
                'target_domain' => $domain, 'career_cluster' => $cluster,
                'readiness' => $readiness['score'], 'employability_band' => $band,
                'animal_primary' => $animal['primary']['id'], 'animal_secondary' => $animal['secondary']['id'],
                'animal_growth' => $animal['growth']['id'],
                'skills_json' => json_encode($skillsOut),
                'projects_json' => json_encode($projects ? [$projects] : []),
                'leadership_json' => json_encode($leadership ? [$leadership] : []),
                'feedback_json' => json_encode([]), 'next_action' => $nextAction,
            ], true);
            (new \App\Models\CandidateProfileModel())->insert([
                'analysis_id' => $savedId, 'session_key' => $sk, 'name' => 'You', 'stage' => $stage,
                'programme' => $programme ?: null, 'cgpa' => $cgpa, 'target_domain' => $domain,
                'animal' => $animal['primary']['id'], 'verified' => $verified, 'evidence_text' => $text,
                'skills_json' => json_encode(array_keys($cand['skills'])), 'readiness' => $readiness['score'],
            ]);
        } catch (\Throwable $e) {
            log_message('error', 'Lumina no-resume persist: ' . $e->getMessage());
        }

        return view('candidate/starter', [
            'title'         => 'Lumina · Starter Living Portfolio',
            'readiness'     => $readiness,
            'band'          => $band,
            'domain'        => $domain,
            'cluster'       => $cluster,
            'animal'        => $animal,
            'skills'        => $skillsOut,
            'gapLabels'     => \App\Libraries\Catalog::labels($bestM['gap']),
            'bestRole'      => $bestRole,
            'resumeDraft'   => $resumeDraft,
            'firstProject'  => $firstProject,
            'activitiesRec' => $activitiesRec,
            'courses'       => $courses,
            'nextAction'    => $nextAction,
            'graphRelated'  => $graph['related'],
            'graphStats'    => $graphStats,
            'graphNew'      => $graphNew,
        ]);
    }

    /** Map free-text tools to skill codes. */
    private function toolsToSkills(string $tools): array
    {
        $t = strtolower($tools); $out = [];
        $map = [
            'python' => 'python', 'sql' => 'sql', 'excel' => 'excel', 'spreadsheet' => 'excel',
            'tableau' => 'dashboarding', 'power bi' => 'dashboarding', 'powerbi' => 'dashboarding',
            'figma' => 'figma', 'photoshop' => 'graphic_design', 'illustrator' => 'graphic_design',
            'canva' => 'graphic_design', 'java' => 'java', 'javascript' => 'javascript',
            'react' => 'javascript', 'node' => 'javascript', 'html' => 'javascript', 'css' => 'javascript',
            'aws' => 'cloud', 'azure' => 'cloud', 'docker' => 'cloud', 'kubernetes' => 'cloud',
            'pandas' => 'data_analysis', 'numpy' => 'data_analysis', 'wordpress' => 'software', 'api' => 'api',
        ];
        foreach ($map as $kw => $code) { if (str_contains($t, $kw)) $out[] = $code; }
        return array_values(array_unique($out));
    }

    // ---------- Fasa 4 helpers ----------

    /** Best-fitting role per domain (Data/Engineering/Business), chosen dynamically from the shared Catalog. */
    private function pathRoles(?array $cand = null): array
    {
        $all = \App\Libraries\Catalog::roles();
        $svc = new ScoreService();
        $out = [];
        foreach (['Data', 'Engineering', 'Business'] as $domain) {
            $inDomain = array_values(array_filter($all, fn ($r) => $r['domain'] === $domain));
            $best = $inDomain[0] ?? null;
            if ($cand && count($inDomain) > 1) {
                $bestScore = -1;
                foreach ($inDomain as $r) {
                    $m = $svc->match($cand, $r)['matchScore'];
                    if ($m > $bestScore) { $bestScore = $m; $best = $r; }
                }
            }
            if ($best) {
                $out[$best['key']] = [
                    'key' => $best['key'], 'title' => $best['title'], 'domain' => $domain,
                    'color' => $best['color'], 'hex' => $best['hex'], 'required' => $best['required'],
                ];
            }
        }
        return $out;
    }

    private function skillLabel(string $c): string
    {
        $m = ['sql' => 'SQL', 'dashboarding' => 'Dashboarding', 'python' => 'Python', 'data_analysis' => 'Data Analysis',
              'software' => 'Software Dev', 'cloud' => 'Cloud', 'communication' => 'Communication',
              'stakeholder_mgmt' => 'Stakeholder Mgmt', 'leadership' => 'Leadership', 'budgeting' => 'Budgeting', 'teamwork' => 'Teamwork'];
        return $m[$c] ?? \App\Libraries\Catalog::label($c);
    }

    private function planFor(array $gap): array
    {
        $g = array_map(fn ($c) => $this->skillLabel($c), $gap);
        return [
            ['d' => '30 days', 'stage' => 'Learn', 't' => $g ? 'Learn ' . $g[0] : 'Strengthen your fundamentals'],
            ['d' => '60 days', 'stage' => 'Build & Prove', 't' => isset($g[1]) ? 'Build a project using ' . $g[0] . ' + ' . $g[1] : ($g ? 'Build a project using ' . $g[0] : 'Build a portfolio project')],
            ['d' => '90 days', 'stage' => 'Apply & Validate', 't' => $g ? 'Add evidence / a cert in ' . implode(', ', array_slice($g, 0, 2)) : 'Get an internship or verified evidence'],
        ];
    }

    private function trajectoryFor(ScoreService $svc, array $cand, array $role, array $gap): array
    {
        // Model the 30/60/90 plan itself (coverage + evidence + activity + pace),
        // so the line rises even when few skill gaps remain — and matches the plan shown below.
        $now = $svc->readiness($cand, $role)['score'];

        // 30d — strengthen fundamentals: close the first skill gap
        $c30 = $cand;
        if (isset($gap[0])) { $c30['skills'][$gap[0]] = ['confidence' => 1.0, 'source' => 'stated']; }
        $d30 = $svc->readiness($c30, $role)['score'];

        // 60d — build a portfolio project: +1 project, +1 activity, close another gap
        $c60 = $c30;
        if (isset($gap[1])) { $c60['skills'][$gap[1]] = ['confidence' => 1.0, 'source' => 'stated']; }
        $c60['projects']   = ($c60['projects'] ?? 0) + 1;
        $c60['activities'] = ($c60['activities'] ?? 0) + 1;
        $d60 = $svc->readiness($c60, $role)['score'];

        // 90d — internship / verified evidence: verify, +1 project, close remaining gaps, faster pace
        $c90 = $c60;
        foreach ($gap as $g) { $c90['skills'][$g] = ['confidence' => 1.0, 'source' => 'stated']; }
        $c90['verified'] = 1;
        $c90['projects'] = ($c90['projects'] ?? 0) + 1;
        $c90['pace']     = 'Fast';
        $d90 = $svc->readiness($c90, $role)['score'];

        // never dip: enforce monotonic non-decreasing for a clean trajectory
        $d30 = max($now, $d30); $d60 = max($d30, $d60); $d90 = max($d60, $d90);

        return ['now' => $now, 'd30' => $d30, 'd60' => $d60, 'd90' => $d90];
    }

    /**
     * Growth Pathway extras (Fasa B6 — Strategic B): "Strength to develop"
     * (from the B1/B2 Potential Profile, if present) and "Role unlocked"
     * (the 90-day projected readiness for this role). Additive only.
     */
    private function growthExtras(?array $potentialProfile, array $traj, string $roleTitle): array
    {
        $strength = null;
        if (! empty($potentialProfile['build_next'][0])) {
            $strength = $potentialProfile['build_next'][0];
        }
        return [
            'strength_to_develop' => $strength,
            'role_unlocked'       => "{$roleTitle} at {$traj['d90']}% readiness",
        ];
    }

    /**
     * Fasa 6.2 — 3 persona demo pilihan (Aiman/Nurul/Wei Jie).
     * Berasingan daripada samplePreset() stage-based. quiz_ps di-set berbeza
     * supaya radar/animal dikira berbeza oleh WorkAnimal — tidak hardcode.
     * Match dikira sistem daripada evidence (bukan hardcode).
     */
    /** Fasa 6.2 — resume penuh berstruktur untuk /resume demo (3 persona). */
    private function personaResume(string $key): string
    {
        $r = [
            'aiman'  => 'Aiman Hakim
BSc Information Technology, Universiti Sains Malaysia · Year 3
CGPA: 3.62 · Career target: Data Analyst

Universiti Sains Malaysia, BSc Information Technology, 2023-2027. CGPA 3.62.

Treasurer of the Computer Science Society for 2 years, managing an RM6,000 annual budget.
Volunteered in a community coding programme teaching Python to 30 secondary students.

Built a faculty attendance web app with Python that cut manual roll-call time by 80%.
Led a student data analysis project and built dashboards used by 5 lecturers.

Python, SQL, data analysis, teamwork.',
            'nurul'  => 'Nurul Aisyah binti Rahman
BBA (Hons) Marketing, Universiti Teknologi MARA (UiTM) · Year 3
CGPA: 3.48 · Career target: Marketing Executive

Universiti Teknologi MARA (UiTM), BBA (Hons) Marketing, 2023-2026. CGPA 3.48.

President of the Entrepreneurship Club, leading a committee of 12 members for one year.
Organised the faculty Market Day, managing an RM8,000 budget and generating RM11,500 in sales.

Led a 5-person team for a digital marketing campaign that grew a client Instagram following from 400 to 3,200 in three months.
Marketing intern at a retail startup, running social media content and weekly sales reports.

Social media marketing, campaign planning, public speaking, event management, budgeting.',
            'weijie' => 'Tan Wei Jie
BEng (Hons) Electrical Engineering, Universiti Teknologi Malaysia (UTM) · Year 4
CGPA: 3.71 · Career target: Electrical Engineer

Universiti Teknologi Malaysia (UTM), BEng (Hons) Electrical Engineering, 2022-2026. CGPA 3.71.

Vice-president of the IEEE student branch, organising two technical workshops.
Finalist in the national RoboCon robotics competition, responsible for the motor control circuit.

Final year project: designed an IoT-based energy monitoring system using ESP32 and current sensors, reducing lab equipment idle power by 22%.
Built a line-following robot with embedded C and designed its PCB from schematic to layout.
Internship at a power systems firm, assisting with circuit testing and PCB inspection.

Circuit design, embedded C, PCB design, MATLAB, IoT, microcontrollers.',
        ];
        return $r[$key] ?? $r['aiman'];
    }

    private function personaPreset(string $key): array
    {
        $personas = [
            'aiman' => [
                'name' => 'Aiman Hakim', 'university' => 'Universiti Sains Malaysia',
                'programme' => 'BSc Information Technology', 'cgpa' => '3.62', 'study_year' => 'Year 3',
                'evidence_text' => self::SAMPLE_MYCSD,
                'stated' => ['python', 'teamwork'], 'domain' => 'Data', 'verified' => 1,
                'quiz_ps' => ['thinking' => 6, 'execution' => 4, 'leadership' => 3],
            ],
            'nurul' => [
                'name' => 'Nurul Aisyah binti Rahman', 'university' => 'Universiti Teknologi MARA (UiTM)',
                'programme' => 'BBA (Hons) Marketing', 'cgpa' => '3.48', 'study_year' => 'Year 3',
                'evidence_text' => 'President of the Entrepreneurship Club, leading a committee of 12 members for one year; '
        . 'organised the faculty Market Day, managing an RM8,000 budget and generating RM11,500 in sales; '
        . 'led a 5-person team for a semester-long digital marketing campaign that grew a client Instagram following from 400 to 3,200 in three months; '
        . 'marketing intern at a retail startup, running social media content and weekly sales reports; '
        . 'coordinated three campus events with external sponsors and vendors.',
                'stated' => ['communication', 'teamwork'], 'domain' => 'Business', 'verified' => 1,
                'quiz_ps' => ['leadership' => 7, 'people' => 5, 'execution' => 3],
            ],
            'weijie' => [
                'name' => 'Tan Wei Jie', 'university' => 'Universiti Teknologi Malaysia (UTM)',
                'programme' => 'BEng (Hons) Electrical Engineering', 'cgpa' => '3.71', 'study_year' => 'Year 4',
                'evidence_text' => 'Final year project: designed an IoT-based energy monitoring system using ESP32 and current sensors, reducing lab equipment idle power by 22%; '
        . 'finalist in the national RoboCon robotics competition, responsible for the motor control circuit; '
        . 'vice-president of the IEEE student branch, organising two technical workshops; '
        . 'internship at a power systems firm, assisting with circuit testing and PCB inspection; '
        . 'built a line-following robot with embedded C and designed its PCB from schematic to layout.',
                'stated' => ['problem_solving', 'teamwork'], 'domain' => 'Engineering', 'verified' => 1,
                'quiz_ps' => ['thinking' => 6, 'execution' => 5, 'adaptability' => 3],
            ],
        ];
        return $personas[$key] ?? $personas['aiman'];
    }

    private function samplePreset(string $stage): array
    {
        $presets = [
            // Strategic C fix: 'quiz_ps' pre-filled (raw EDGE Signal tally)
            // since sample personas never answer the /onboard/animal quiz.
            '16-18'  => ['name' => 'Nurul', 'university' => 'Pre-U', 'programme' => 'STEM stream', 'evidence_text' => 'Active in Science Club; built a small weather logger; enjoys maths.', 'stated' => ['data_analysis'], 'domain' => 'Data', 'animal' => 'owl', 'verified' => 0, 'quiz_ps' => ['thinking' => 7, 'learning' => 4, 'execution' => 2]],
            '19-22'  => ['name' => 'Aiman Hakim', 'university' => 'Universiti Sains Malaysia', 'programme' => 'BSc Information Technology', 'cgpa' => '3.62', 'study_year' => 'Year 3', 'evidence_text' => self::SAMPLE_MYCSD, 'stated' => ['python', 'teamwork'], 'domain' => 'Data', 'animal' => 'owl', 'verified' => 1, 'quiz_ps' => ['thinking' => 6, 'execution' => 4, 'leadership' => 3]],
            '23-28'  => ['name' => 'Wei Jie', 'university' => 'Universiti Malaya', 'programme' => 'BSc Data Science', 'study_year' => 'Year 4', 'evidence_text' => 'Internship at a fintech; built dashboards; led a small analytics team.', 'stated' => ['sql', 'dashboarding', 'python'], 'domain' => 'Data', 'animal' => 'fox', 'verified' => 1, 'quiz_ps' => ['adaptability' => 6, 'leadership' => 5, 'execution' => 3]],
            '26-28+' => ['name' => 'Sara', 'university' => 'Universiti Teknologi Malaysia', 'programme' => 'BSc Software Engineering', 'evidence_text' => '3 years backend dev; mentors juniors; shipped cloud microservices.', 'stated' => ['software', 'cloud', 'communication'], 'domain' => 'Engineering', 'animal' => 'eagle', 'verified' => 1, 'quiz_ps' => ['leadership' => 7, 'people' => 5, 'execution' => 4]],
        ];
        return $presets[$stage] ?? $presets['19-22'];
    }

    /** Detect persona dari nama profil (untuk cadangan Add demo). */
    private function edgePersonaFromName(string $name): string
    {
        $n = strtolower($name);
        if (strpos($n, 'aiman') !== false) return 'aiman';
        if (strpos($n, 'nurul') !== false) return 'nurul';
        if (strpos($n, 'wei jie') !== false || strpos($n, 'weijie') !== false) return 'weijie';
        return 'self';
    }

    private function edgePersona(): string
    {
        $n = strtolower(session('profile')['name'] ?? '');
        if (strpos($n, 'aiman') !== false) return 'aiman';
        if (strpos($n, 'nurul') !== false) return 'nurul';
        if (strpos($n, 'wei jie') !== false || strpos($n, 'weijie') !== false) return 'weijie';
        return 'self';
    }

    /** Nama 5 signal EDGE untuk chip table. */
    private function edgeSignalNames(): array
    {
        $out = [];
        foreach (Edge::order() as $sk) { $out[$sk] = Edge::signalName($sk); }
        return $out;
    }

    /**
     * Fasa 2c: simpan tindakan Review (Keep/Remove/Edit/Add) ke profile['edge'].
     * JSON body: {action:'remove'|'add'|'edit', id?, quote?, signals?, outcome?}
     */
    public function edgeaction()
    {
        $in = $this->request->getJSON(true) ?? [];
        $action = $in['action'] ?? '';
        $profile = session('profile') ?? [];
        $edge = $profile['edge'] ?? [];
        if (! $edge && $action !== 'add') { return $this->response->setJSON(['ok'=>false,'msg'=>'no_edge']); }

        if ($action === 'remove') {
            // buang evidence yang quote-nya sepadan id (id = urutan suggestion)
            $targetQuote = $in['quote'] ?? null;
            // jika id sahaja, kita padam ikut quote yang dihantar semula; fallback: guna suggestions
            $sug = Edge::suggestions($edge);
            foreach ($sug as $row) {
                if ((string)$row['id'] === (string)($in['id'] ?? '')) { $targetQuote = $row['quote']; break; }
            }
            if ($targetQuote !== null) {
                foreach ($edge as $k => $sig) {
                    if (empty($sig['evidence'])) continue;
                    $edge[$k]['evidence'] = array_values(array_filter($sig['evidence'], function($ev) use ($targetQuote) {
                        return ($ev['quote'] ?? '') !== $targetQuote;
                    }));
                    // turunkan status jika tiada evidence lagi
                    if (empty($edge[$k]['evidence']) && ($edge[$k]['status'] ?? '') === 'inferred') {
                        $edge[$k]['status'] = empty($edge[$k]['responses']) ? 'needs' : 'stated';
                    }
                }
            }
        } elseif ($action === 'add') {
            $quote = trim((string)($in['quote'] ?? ''));
            $signals = $in['signals'] ?? [];
            if ($quote !== '' && $signals) {
                foreach ($signals as $sig) {
                    if (! isset($edge[$sig])) { $edge[$sig] = ['status'=>'needs','evidence'=>[],'responses'=>[]]; }
                    $edge[$sig]['evidence'][] = ['quote'=>$quote,'skill'=>'self_added','source'=>'supported'];
                    $edge[$sig]['status'] = 'supported';
                }
            }
        } elseif ($action === 'edit') {
            $outcome = trim((string)($in['outcome'] ?? ''));
            $sug = Edge::suggestions($edge);
            $targetQuote = null;
            foreach ($sug as $row) { if ((string)$row['id'] === (string)($in['id'] ?? '')) { $targetQuote = $row['quote']; break; } }
            if ($targetQuote !== null && $outcome !== '') {
                foreach ($edge as $k => $sig) {
                    if (empty($sig['evidence'])) continue;
                    foreach ($edge[$k]['evidence'] as $i => $ev) {
                        if (($ev['quote'] ?? '') === $targetQuote) {
                            $edge[$k]['evidence'][$i]['outcome'] = $outcome;
                            $edge[$k]['evidence'][$i]['source'] = 'supported';
                            $edge[$k]['status'] = 'supported';
                        }
                    }
                }
            }
        }

        $profile['edge'] = $edge;
        session()->set('profile', $profile);
        return $this->response->setJSON(['ok'=>true]);
    }

}
