<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<?php helper('ui'); $first = $paths[0]; ?>

<section class="hero">
  <div class="section-label" id="cEyebrow" data-normal="Prepare · Choose a direction" data-progress="Progress · Build your next proof">Prepare · Choose a direction</div>
  <h1 id="cHeading" data-normal="Where you are. Where you can go. What's next." data-progress="Turn your next skill into visible proof.">Where you are. Where you can go. What's next.</h1>
  <p class="purpose" id="cSub" data-normal="Pick a path, then add a skill and watch your readiness move." data-progress="Your 30 / 60 / 90-day plan turns a career gap into an action you can show.">Pick a path, then add a skill and watch your readiness move.</p>
</section>

<section class="section" style="padding-top:6px">
  <?= lumina_career_journey('prepare') ?>
  <?= lumina_note("Your current target is Data Analyst. These are nearby directions based on your portfolio — and how ready you are for each.") ?>
</section>

<!-- Path cards -->
<section class="section">
  <div class="grid grid-3" id="recommendedPaths">
    <?php foreach ($paths as $i => $p): ?>
      <div class="card path-card <?= $i === 0 ? 'sel' : '' ?>" data-key="<?= esc($p['key']) ?>" role="button" tabindex="0"
           style="--pc:<?= $p['color'] ?>">
        <div class="row" style="justify-content:space-between">
          <h3 style="margin:0"><?= esc($p['title']) ?></h3>
          <span class="pill <?= $p['label']==='best'?'ok':($p['label']==='growth'?'nudge':'risk') ?>"><?= esc(ucfirst($p['label'])) ?> fit</span>
        </div>
        <div style="margin-top:10px">
          <?php if ($p['gaps']): $gapCount = count($p['gaps']); ?>
          <div style="display:flex;align-items:center;gap:8px;font-size:13px;margin-bottom:4px">
            <span style="width:8px;height:8px;border-radius:50%;background:var(--pc);flex-shrink:0"></span>
            <span><strong><?= $gapCount ?></strong> skill<?= $gapCount==1?'':'s' ?> to build: <?= esc(implode(', ', array_map(fn($g)=>$g['label'],$p['gaps']))) ?></span>
          </div>
          <div class="muted" style="font-size:12px">A focused 30–60–90 day plan gets you there — tap to see it.</div>
          <?php else: ?>
          <div style="display:flex;align-items:center;gap:8px;font-size:13px">
            <span style="width:8px;height:8px;border-radius:50%;background:#4ade80;flex-shrink:0"></span>
            <span>No gaps — you're ready for this direction.</span>
          </div>
          <?php endif; ?>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
</section>

<!-- Detail: What-If + trajectory -->
<section class="section">
  <div class="grid grid-2">

    <div class="card" id="growthPathway">
      <div class="section-label" id="cPathLabel"><?= esc($first['title']) ?></div>
      <div class="donut-wrap" id="cDonut"><?= lumina_donut($first['readiness'], 'Readiness', $first['color']) ?></div>
      <div style="text-align:center;font-size:15px;margin:6px 0 14px" id="deltaTxt"><?= (int)$first['readiness'] ?>%</div>

      <h3 style="margin-bottom:8px">Add a skill — see it move</h3>
      <div id="gapList" class="stack"></div>
      <p class="purpose" style="margin-top:10px">Decision support only. This is your trajectory, not a guarantee.</p>
    </div>

    <div class="card">
      <div class="section-label">Your trajectory</div>
      <canvas id="trajChart" height="150"></canvas>
      <h3 style="margin:16px 0 8px">30 / 60 / 90-day plan</h3>
      <div id="planList" class="stack"></div>
      <a id="cReviewCta" class="btn btn-primary" href="<?= base_url('match') ?>" style="display:none;margin-top:12px">Review opportunities →</a>
      <div id="cStrength" class="muted" style="font-size:13px;margin-top:10px"></div>
      <div id="cUnlocked" class="muted" style="font-size:13px;margin-top:4px"></div>
    </div>

  </div>

  <div class="row" style="margin-top:18px">
    <a id="cFindBtn" class="btn btn-primary btn-lg" href="<?= base_url('match') ?>">Find opportunities →</a>
    <a class="btn btn-ghost" href="<?= base_url('passport') ?>">← Back to portfolio</a>
  </div>
</section>

<?php if (!empty($chosenPath)): ?>
<!-- Chosen Pathway (Strategic B6) -->
<section class="section">
  <div class="section-label">Your Chosen Pathway</div>
  <div class="card" style="--pc:<?= $chosenPath['color'] ?>">
    <div class="row" style="justify-content:space-between;align-items:center">
      <h3 style="margin:0"><?= esc($chosenPath['title']) ?></h3>
      <span class="pill <?= $chosenPath['label']==='best'?'ok':($chosenPath['label']==='growth'?'nudge':'risk') ?>"><?= (int)$chosenPath['readiness'] ?>% ready</span>
    </div>
    <div class="muted" style="font-size:13px;margin-top:10px">
      <?php foreach ($chosenPath['plan'] as $s): ?>
        <div style="margin-bottom:4px"><strong class="gold"><?= esc($s['stage'] ?? $s['d']) ?></strong> (<?= esc($s['d']) ?>) — <?= esc($s['t']) ?></div>
      <?php endforeach; ?>
    </div>
    <?php if (!empty($chosenPath['strength_to_develop'])): ?>
      <p class="muted" style="font-size:13px;margin-top:8px">Strength to develop: <strong style="color:var(--text)"><?= esc($chosenPath['strength_to_develop']) ?></strong></p>
    <?php endif; ?>
    <p class="muted" style="font-size:13px">Unlocks: <strong class="gold"><?= esc($chosenPath['role_unlocked']) ?></strong></p>
  </div>
</section>
<?php endif; ?>

<!-- Explore Another Career (Strategic B5) -->
<section class="section">
  <div class="section-label">Explore Another Career</div>
  <p class="purpose">Not one of your top 3 paths? Pick any role and see where you stand today.</p>
  <div class="row" style="gap:10px;flex-wrap:wrap;align-items:center">
    <select id="eRoleSelect" style="padding:9px 11px;border-radius:8px;border:1px solid var(--line);background:rgba(255,255,255,.03);color:inherit;font-size:14px">
      <?php foreach ($allRoles as $r): ?>
        <option value="<?= esc($r['key']) ?>"><?= esc($r['title']) ?> · <?= esc($r['domain']) ?></option>
      <?php endforeach; ?>
    </select>
    <button class="btn btn-gold" id="eGoBtn">Show my pathway →</button>
  </div>
  <div id="eResult" style="display:none;margin-top:16px">
    <div class="row" style="justify-content:space-between;align-items:center">
      <h3 id="eTitle" style="margin:0"></h3>
      <span class="pill" id="eFitPill"></span>
    </div>
    <div class="grid grid-2" style="margin-top:12px">
      <div class="card">
        <div class="donut-wrap" id="eDonut"></div>
        <div id="eMatched" class="muted" style="font-size:13px;margin:10px 0"></div>
        <h3 style="margin:12px 0 8px">Skills to build</h3>
        <div id="eGapList" class="stack"></div>
      </div>
      <div class="card">
        <div class="section-label">Your trajectory</div>
        <canvas id="eTrajChart" height="150"></canvas>
        <h3 style="margin:16px 0 8px">30 / 60 / 90-day plan</h3>
        <div id="ePlanList" class="stack"></div>
        <div id="eStrength" class="muted" style="font-size:13px;margin-top:10px"></div>
        <div id="eUnlocked" class="muted" style="font-size:13px;margin-top:4px"></div>
      </div>
    </div>
    <div id="eInterviewPrep" style="margin-top:14px"></div>
  </div>
</section>

<!-- data + scripts -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<script>
const PATHS = <?= json_encode(array_map(fn($p)=>[
  'key'=>$p['key'],'title'=>$p['title'],'readiness'=>$p['readiness'],
  'colorHex'=>$p['colorHex'],'gaps'=>$p['gaps'],'plan'=>$p['plan'],'traj'=>$p['traj'],
  'strength_to_develop'=>$p['strength_to_develop'] ?? null,'role_unlocked'=>$p['role_unlocked'] ?? null
], $paths)) ?>;
const WHATIF_URL = "<?= base_url('whatif') ?>";
let active = PATHS[0], chart = null;

function setDonut(pct, color){
  const wrap = document.getElementById('cDonut');
  const val = wrap.querySelector('.val'), txt = wrap.querySelector('.pct');
  const r = 45, c = 2*Math.PI*r;
  val.style.stroke = color;
  val.style.strokeDasharray = c.toFixed(1);
  val.style.strokeDashoffset = (c*(1-pct/100)).toFixed(1);
  txt.textContent = pct + '%';
}
function setDelta(before, after, delta){
  document.getElementById('deltaTxt').innerHTML =
    before + '% → <strong>' + after + '%</strong>' + (delta>0 ? ' <span class="gold">(+'+delta+')</span>' : '');
}
function buildGaps(p){
  const box = document.getElementById('gapList');
  if(!p.gaps.length){ box.innerHTML = '<p class="muted">No gaps — you are a strong match already.</p>'; return; }
  box.innerHTML = p.gaps.map(g =>
    '<label class="opt"><input type="checkbox" class="gap-cb" value="'+g.code+'">'+
    '<span class="opt-box">Add '+g.label+'</span></label>').join('');
}
function buildPlan(p){
  document.getElementById('planList').innerHTML = p.plan.map(s =>
    '<div class="ev"><strong class="gold">'+s.d+'</strong>'+(s.stage?' <span class="muted" style="font-size:11px">('+s.stage+')</span>':'')+' — '+s.t+'</div>').join('');
}
function renderChart(p){
  const ctx = document.getElementById('trajChart').getContext('2d');
  const data = [p.traj.now, p.traj.d30, p.traj.d60, p.traj.d90];
  if(chart) chart.destroy();
  chart = new Chart(ctx, {
    type:'line',
    data:{ labels:['Now','30d','60d','90d'], datasets:[{ data, borderColor:p.colorHex,
      backgroundColor:'transparent', tension:.35, pointRadius:4, pointBackgroundColor:p.colorHex, borderWidth:3 }] },
    options:{ plugins:{legend:{display:false}}, scales:{
      y:{ min:0, max:100, grid:{color:'rgba(255,255,255,.06)'}, ticks:{color:'#9AA4B8'} },
      x:{ grid:{display:false}, ticks:{color:'#9AA4B8'} } } }
  });
}
function recompute(){
  const checked = [...document.querySelectorAll('.gap-cb:checked')].map(c=>c.value);
  const body = new URLSearchParams(); body.append('role', active.key);
  checked.forEach(c => body.append('add[]', c));
  fetch(WHATIF_URL, {method:'POST', headers:{'X-Requested-With':'XMLHttpRequest'}, body})
    .then(r=>r.json())
    .then(w=>{ setDonut(w.after, active.colorHex); setDelta(w.before, w.after, w.delta); })
    .catch(()=>{});
}
function selectPath(key){
  active = PATHS.find(p=>p.key===key) || PATHS[0];
  document.querySelectorAll('.path-card').forEach(c=>c.classList.toggle('sel', c.dataset.key===active.key));
  document.getElementById('cPathLabel').textContent = active.title;
  setDonut(active.readiness, active.colorHex);
  document.getElementById('deltaTxt').textContent = 'Choose a skill below to preview its impact.';
  buildGaps(active); buildPlan(active); renderChart(active);
  document.getElementById('cStrength').innerHTML = active.strength_to_develop
    ? ('Strength to develop: <strong style="color:var(--text)">'+active.strength_to_develop+'</strong>') : '';
  document.getElementById('cUnlocked').innerHTML = active.role_unlocked
    ? ('Unlocks: <strong class="gold">'+active.role_unlocked+'</strong>') : '';
}
document.addEventListener('click', e=>{
  const card = e.target.closest('.path-card'); if(card){ selectPath(card.dataset.key); }
  if(e.target.classList.contains('gap-cb')){ recompute(); }
});
document.addEventListener('change', e=>{ if(e.target.classList.contains('gap-cb')) recompute(); });
selectPath(PATHS[0].key);

// ---- Career Action Journey: Progress view via #growthPathway ----
(function(){
  function setStage(stage, done){
    document.querySelectorAll('.career-journey .jstep').forEach(function(a){
      var s = a.getAttribute('data-journey-stage');
      var order = {prepare:0, apply:1, perform:2, progress:3};
      var i = order[s];
      var dot = a.querySelector('.jdot');
      a.classList.remove('active','done'); a.removeAttribute('aria-current');
      if (i < done){ a.classList.add('done'); if(dot) dot.innerHTML = '&#10003;'; }
      else { if(dot) dot.textContent = (i+1); }
      if (s === stage){ a.classList.add('active'); a.setAttribute('aria-current','step'); }
    });
  }
  function txt(id, key){
    var el = document.getElementById(id); if(!el) return;
    var v = el.getAttribute('data-'+key); if(v!==null) el.textContent = v;
  }
  function applyProgress(){
    var on = (location.hash === '#growthPathway');
    txt('cEyebrow', on?'progress':'normal');
    txt('cHeading', on?'progress':'normal');
    txt('cSub',     on?'progress':'normal');
    var cta = document.getElementById('cReviewCta'); if(cta) cta.style.display = on?'inline-flex':'none';
    var fb = document.getElementById('cFindBtn'); if(fb) fb.style.display = on?'none':'inline-flex';
    if (on){ setStage('progress', 3);
      var t = document.getElementById('growthPathway'); if(t) t.scrollIntoView({behavior:'smooth', block:'start'});
    } else { setStage('prepare', 0); }
  }
  window.addEventListener('hashchange', applyProgress);
  applyProgress();
})();

// ---- Explore Another Career (Strategic B5) ----
const EXPLORE_URL = "<?= base_url('compass/explore') ?>";
let exploreChart = null;
function donutSVGFor(pct, color){
  const r=45, c=2*Math.PI*r, off = c*(1-pct/100);
  return '<svg class="donut" viewBox="0 0 120 120">'+
    '<circle class="track" cx="60" cy="60" r="'+r+'"></circle>'+
    '<circle class="val" cx="60" cy="60" r="'+r+'" style="stroke:'+color+';stroke-dasharray:'+c.toFixed(1)+';stroke-dashoffset:'+off.toFixed(1)+'"></circle>'+
    '<text class="pct" x="60" y="68" text-anchor="middle">'+pct+'%</text></svg>';
}
function renderExplore(e){
  if(e.error){ return; }
  document.getElementById('eResult').style.display = '';
  document.getElementById('eTitle').textContent = e.title;
  var fitClass = e.fitLabel==='Ready Now'?'ok':(e.fitLabel==='Reachable'?'nudge':'risk');
  var pill = document.getElementById('eFitPill');
  pill.className = 'pill '+fitClass;
  pill.textContent = e.fitLabel;
  document.getElementById('eDonut').innerHTML = donutSVGFor(e.readiness, e.colorHex);
  document.getElementById('eMatched').innerHTML = (e.matched && e.matched.length)
    ? 'Transferable strengths: <strong style="color:var(--text)">'+e.matched.map(function(m){return m.label;}).join(', ')+'</strong>'
    : '';
  document.getElementById('eGapList').innerHTML = (e.gaps && e.gaps.length)
    ? e.gaps.map(function(g){return '<span class="skill">'+g.label+'</span>';}).join(' ')
    : '<p class="muted">No gaps — strong match already.</p>';
  document.getElementById('ePlanList').innerHTML = e.plan.map(function(s){
    return '<div class="ev"><strong class="gold">'+s.d+'</strong>'+(s.stage?' <span class="muted" style="font-size:11px">('+s.stage+')</span>':'')+' — '+s.t+'</div>';
  }).join('');
  document.getElementById('eStrength').innerHTML = e.strength_to_develop
    ? ('Strength to develop: <strong style="color:var(--text)">'+e.strength_to_develop+'</strong>') : '';
  document.getElementById('eUnlocked').innerHTML = e.role_unlocked
    ? ('Unlocks: <strong class="gold">'+e.role_unlocked+'</strong>') : '';
  document.getElementById('eInterviewPrep').innerHTML = (e.interview_prep && e.interview_prep.length)
    ? '<div class="section-label" style="margin-top:4px">Questions they might ask</div>' + e.interview_prep.map(function(q,i){
        return '<div class="muted" style="font-size:13px;margin-top:4px">'+(i+1)+'. '+q+'</div>';
      }).join('')
    : '';
  if(exploreChart) exploreChart.destroy();
  var ctx = document.getElementById('eTrajChart').getContext('2d');
  exploreChart = new Chart(ctx, {
    type:'line',
    data:{ labels:['Now','30d','60d','90d'], datasets:[{ data:[e.traj.now,e.traj.d30,e.traj.d60,e.traj.d90], borderColor:e.colorHex,
      backgroundColor:'transparent', tension:.35, pointRadius:4, pointBackgroundColor:e.colorHex, borderWidth:3 }] },
    options:{ plugins:{legend:{display:false}}, scales:{
      y:{ min:0, max:100, grid:{color:'rgba(255,255,255,.06)'}, ticks:{color:'#9AA4B8'} },
      x:{ grid:{display:false}, ticks:{color:'#9AA4B8'} } } }
  });
}
document.getElementById('eGoBtn').onclick = function(){
  var key = document.getElementById('eRoleSelect').value;
  var body = new URLSearchParams(); body.append('role', key);
  fetch(EXPLORE_URL, {method:'POST', headers:{'X-Requested-With':'XMLHttpRequest'}, body})
    .then(function(r){return r.json();})
    .then(renderExplore)
    .catch(function(){});
};
</script>

<?= $this->endSection() ?>
